<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
delete_option('aizy_seo_redirects');
delete_option('aizy_seo_instellingen');
