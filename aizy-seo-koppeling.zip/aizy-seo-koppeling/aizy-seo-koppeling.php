<?php
/**
 * Plugin Name: Aizy SEO-koppeling
 * Description: Koppelt deze site aan het Aizy SEO-dashboard: SEO-titel en -beschrijving, noindex en canonical (Yoast of Rank Math), URL wijzigen met 301, redirects, WooCommerce-categorieteksten met terugzetten, alt-teksten en het CTA-blok [aizy_cta].
 * Version: 1.0.0
 * Author: Aizy
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) exit;

define('AIZY_SEO_VERSIE', '1.0.0');
const AIZY_SEO_REDIRECTS = 'aizy_seo_redirects';
const AIZY_SEO_INSTELLINGEN = 'aizy_seo_instellingen';

/* ── Hulpfuncties ─────────────────────────────────────────────────────────── */
function aizy_seo_plugin() {
	if (defined('RANK_MATH_VERSION') || class_exists('RankMath')) return 'rankmath';
	if (defined('WPSEO_VERSION')) return 'yoast';
	return 'geen';
}
function aizy_seo_pad($url) {
	$p = wp_parse_url($url, PHP_URL_PATH);
	$p = '/' . trim((string) $p, '/');
	return strtolower($p === '/' ? '/' : $p);
}
function aizy_seo_mag() { return current_user_can('edit_others_posts') || current_user_can('manage_woocommerce'); }
function aizy_seo_term_op_pad($pad) {
	if (!taxonomy_exists('product_cat')) return null;
	$delen = array_values(array_filter(explode('/', trim($pad, '/'))));
	$slug = end($delen);
	if (!$slug) return null;
	$t = get_term_by('slug', sanitize_title($slug), 'product_cat');
	return $t ?: null;
}

/* ── REST-routes (namespace aizy-seo/v1, aanmelden met een applicatiewachtwoord) ── */
add_action('rest_api_init', function () {
	$mag = 'aizy_seo_mag';

	register_rest_route('aizy-seo/v1', '/status', array('methods' => 'GET', 'permission_callback' => $mag, 'callback' => function () {
		return array(
			'versie' => AIZY_SEO_VERSIE, 'seo_plugin' => aizy_seo_plugin(), 'woocommerce' => class_exists('WooCommerce'),
			'redirects' => count((array) get_option(AIZY_SEO_REDIRECTS, array())), 'wp' => get_bloginfo('version'), 'site' => home_url('/'),
		);
	}));

	// Pad → bericht/pagina/categorie
	register_rest_route('aizy-seo/v1', '/zoek', array('methods' => 'GET', 'permission_callback' => $mag, 'callback' => function (WP_REST_Request $v) {
		$pad = aizy_seo_pad((string) $v->get_param('pad'));
		$id = url_to_postid(home_url($pad));
		if ($id) { $type = get_post_type($id); return array('id' => $id, 'type' => $type, 'rest' => $type === 'page' ? 'pages' : ($type === 'post' ? 'posts' : $type)); }
		$t = aizy_seo_term_op_pad($pad);
		if ($t) return array('term_id' => $t->term_id, 'type' => 'product_cat');
		return new WP_Error('niet_gevonden', 'Geen bericht, pagina of categorie op dit pad', array('status' => 404));
	}));

	// SEO-velden: titel, beschrijving, focuszoekwoord, noindex, canonical
	register_rest_route('aizy-seo/v1', '/seo', array('methods' => 'POST', 'permission_callback' => $mag, 'callback' => function (WP_REST_Request $v) {
		$id = (int) $v->get_param('id');
		if (!$id || !get_post($id)) return new WP_Error('geen_id', 'Onbekend bericht', array('status' => 404));
		$p = aizy_seo_plugin();
		$k = $p === 'rankmath'
			? array('titel' => 'rank_math_title', 'meta' => 'rank_math_description', 'zoekwoord' => 'rank_math_focus_keyword', 'canonical' => 'rank_math_canonical_url')
			: array('titel' => '_yoast_wpseo_title', 'meta' => '_yoast_wpseo_metadesc', 'zoekwoord' => '_yoast_wpseo_focuskw', 'canonical' => '_yoast_wpseo_canonical');
		foreach (array('titel', 'meta', 'zoekwoord', 'canonical') as $veld) {
			$w = $v->get_param($veld);
			if ($w === null) continue;
			$w = $veld === 'canonical' ? esc_url_raw($w) : sanitize_text_field($w);
			if ($w === '') delete_post_meta($id, $k[$veld]); else update_post_meta($id, $k[$veld], $w);
		}
		$noindex = $v->get_param('noindex');
		if ($noindex !== null) {
			if ($p === 'rankmath') {
				$r = array_values(array_diff((array) get_post_meta($id, 'rank_math_robots', true), array('index', 'noindex')));
				$r[] = $noindex ? 'noindex' : 'index';
				update_post_meta($id, 'rank_math_robots', $r);
			} else {
				update_post_meta($id, '_yoast_wpseo_meta-robots-noindex', $noindex ? '1' : '2');
			}
			update_post_meta($id, '_aizy_noindex', $noindex ? '1' : '0');
		}
		return array('ok' => true, 'seo_plugin' => $p);
	}));

	// URL wijzigen + automatisch een 301 van het oude naar het nieuwe pad
	register_rest_route('aizy-seo/v1', '/slug', array('methods' => 'POST', 'permission_callback' => $mag, 'callback' => function (WP_REST_Request $v) {
		$oud = aizy_seo_pad((string) $v->get_param('pad'));
		$nieuw = sanitize_title((string) $v->get_param('nieuw'));
		if (!$nieuw) return new WP_Error('geen_slug', 'Geef een nieuwe slug', array('status' => 400));
		$id = url_to_postid(home_url($oud));
		if ($id) {
			wp_update_post(array('ID' => $id, 'post_name' => $nieuw));
			$url = get_permalink($id);
		} else {
			$t = aizy_seo_term_op_pad($oud);
			if (!$t) return new WP_Error('niet_gevonden', 'Pad niet gevonden', array('status' => 404));
			wp_update_term($t->term_id, 'product_cat', array('slug' => $nieuw));
			$url = get_term_link($t->term_id, 'product_cat');
		}
		$nieuw_pad = aizy_seo_pad($url);
		if ($nieuw_pad !== $oud) aizy_seo_redirect_zet($oud, $nieuw_pad);
		return array('ok' => true, 'url' => $url, 'nieuw_pad' => $nieuw_pad);
	}));

	// Redirects: lijst, toevoegen, verwijderen
	register_rest_route('aizy-seo/v1', '/redirects', array(
		array('methods' => 'GET', 'permission_callback' => $mag, 'callback' => function () {
			$l = (array) get_option(AIZY_SEO_REDIRECTS, array()); $uit = array();
			foreach ($l as $van => $r) $uit[] = array('van' => $van, 'naar' => $r['naar'], 'gemaakt' => $r['gemaakt'] ?? null, 'hits' => $r['hits'] ?? 0);
			return array('redirects' => $uit);
		}),
		array('methods' => 'POST', 'permission_callback' => $mag, 'callback' => function (WP_REST_Request $v) {
			$van = aizy_seo_pad((string) $v->get_param('van')); $naar = aizy_seo_pad((string) $v->get_param('naar'));
			if ($van === '/' || $van === $naar) return new WP_Error('ongeldig', 'Ongeldige redirect', array('status' => 400));
			aizy_seo_redirect_zet($van, $naar);
			return array('ok' => true, 'van' => $van, 'naar' => $naar);
		}),
		array('methods' => 'DELETE', 'permission_callback' => $mag, 'callback' => function (WP_REST_Request $v) {
			$l = (array) get_option(AIZY_SEO_REDIRECTS, array()); $van = aizy_seo_pad((string) $v->get_param('van'));
			unset($l[$van]); update_option(AIZY_SEO_REDIRECTS, $l, false);
			return array('ok' => true);
		}),
	));

	// WooCommerce-categorietekst: intro (beschrijving) en tekst onder de producten; vorige versie wordt bewaard
	register_rest_route('aizy-seo/v1', '/categorie', array('methods' => 'POST', 'permission_callback' => $mag, 'callback' => function (WP_REST_Request $v) {
		$t = aizy_seo_term_op_pad(aizy_seo_pad((string) $v->get_param('pad')));
		if (!$t) return new WP_Error('niet_gevonden', 'Categorie niet gevonden', array('status' => 404));
		update_term_meta($t->term_id, 'aizy_cat_vorige', array(
			'intro' => $t->description, 'onder' => get_term_meta($t->term_id, 'aizy_cat_onder', true),
			'titel' => get_term_meta($t->term_id, aizy_seo_plugin() === 'rankmath' ? 'rank_math_title' : '_aizy_titel', true),
			'meta' => get_term_meta($t->term_id, aizy_seo_plugin() === 'rankmath' ? 'rank_math_description' : '_aizy_meta', true),
			'tijd' => current_time('mysql'),
		));
		if ($v->get_param('intro') !== null) wp_update_term($t->term_id, 'product_cat', array('description' => wp_kses_post($v->get_param('intro'))));
		if ($v->get_param('onder') !== null) update_term_meta($t->term_id, 'aizy_cat_onder', wp_kses_post($v->get_param('onder')));
		aizy_seo_term_seo($t->term_id, $v->get_param('titel'), $v->get_param('meta'));
		return array('ok' => true, 'term_id' => $t->term_id);
	}));
	register_rest_route('aizy-seo/v1', '/categorie/terugzetten', array('methods' => 'POST', 'permission_callback' => $mag, 'callback' => function (WP_REST_Request $v) {
		$t = aizy_seo_term_op_pad(aizy_seo_pad((string) $v->get_param('pad')));
		if (!$t) return new WP_Error('niet_gevonden', 'Categorie niet gevonden', array('status' => 404));
		$o = get_term_meta($t->term_id, 'aizy_cat_vorige', true);
		if (!is_array($o)) return new WP_Error('geen_vorige', 'Geen vorige versie', array('status' => 400));
		wp_update_term($t->term_id, 'product_cat', array('description' => $o['intro']));
		update_term_meta($t->term_id, 'aizy_cat_onder', $o['onder']);
		aizy_seo_term_seo($t->term_id, $o['titel'], $o['meta']);
		delete_term_meta($t->term_id, 'aizy_cat_vorige');
		return array('ok' => true);
	}));

	// Beelden op een pagina (ook Elementor) met hun alt; POST zet alt-teksten op de mediabestanden
	register_rest_route('aizy-seo/v1', '/beelden/(?P<id>\d+)', array(
		array('methods' => 'GET', 'permission_callback' => $mag, 'callback' => function (WP_REST_Request $v) {
			$id = (int) $v['id']; $post = get_post($id);
			if (!$post) return new WP_Error('geen_id', 'Onbekend bericht', array('status' => 404));
			$ids = array();
			if (has_post_thumbnail($id)) $ids[] = (int) get_post_thumbnail_id($id);
			preg_match_all('/wp-image-(\d+)/', $post->post_content, $m); $ids = array_merge($ids, array_map('intval', $m[1]));
			$el = get_post_meta($id, '_elementor_data', true);
			if ($el) { preg_match_all('/"id"\s*:\s*"?(\d+)"?\s*,\s*"url"/', (string) $el, $m2); $ids = array_merge($ids, array_map('intval', $m2[1])); }
			$uit = array();
			foreach (array_unique(array_filter($ids)) as $mid) {
				if (get_post_type($mid) !== 'attachment') continue;
				$uit[] = array('media_id' => $mid, 'bestand' => basename((string) get_attached_file($mid)), 'alt' => (string) get_post_meta($mid, '_wp_attachment_image_alt', true),
					'bijschrift' => wp_get_attachment_caption($mid), 'context' => get_the_title($mid));
			}
			return array('titel' => get_the_title($id), 'beelden' => $uit);
		}),
		array('methods' => 'POST', 'permission_callback' => $mag, 'callback' => function (WP_REST_Request $v) {
			$id = (int) $v['id']; $gezet = 0;
			foreach ((array) $v->get_param('alts') as $mid => $alt) {
				$mid = (int) $mid; $alt = sanitize_text_field($alt);
				if (!$mid || !$alt || get_post_type($mid) !== 'attachment') continue;
				update_post_meta($mid, '_wp_attachment_image_alt', $alt); $gezet++;
			}
			if (did_action('elementor/loaded') && class_exists('\Elementor\Plugin')) { delete_post_meta($id, '_elementor_element_cache'); }
			clean_post_cache($id);
			return array('ok' => true, 'gezet' => $gezet);
		}),
	));
});

function aizy_seo_term_seo($term_id, $titel, $meta) {
	$rm = aizy_seo_plugin() === 'rankmath';
	if ($titel !== null) update_term_meta($term_id, $rm ? 'rank_math_title' : '_aizy_titel', sanitize_text_field($titel));
	if ($meta !== null) update_term_meta($term_id, $rm ? 'rank_math_description' : '_aizy_meta', sanitize_text_field($meta));
	if (!$rm && aizy_seo_plugin() === 'yoast') {
		// Yoast bewaart term-meta in één optie
		$o = get_option('wpseo_taxonomy_meta', array());
		if ($titel !== null) $o['product_cat'][$term_id]['wpseo_title'] = sanitize_text_field($titel);
		if ($meta !== null) $o['product_cat'][$term_id]['wpseo_desc'] = sanitize_text_field($meta);
		update_option('wpseo_taxonomy_meta', $o);
	}
}

/* ── Redirects uitvoeren ──────────────────────────────────────────────────── */
function aizy_seo_redirect_zet($van, $naar) {
	$l = (array) get_option(AIZY_SEO_REDIRECTS, array());
	// Geen ketens: wat naar $van wees, wijst nu direct naar $naar
	foreach ($l as $k => $r) if ($r['naar'] === $van) $l[$k]['naar'] = $naar;
	unset($l[$naar]);
	$l[$van] = array('naar' => $naar, 'gemaakt' => current_time('mysql'), 'hits' => 0);
	update_option(AIZY_SEO_REDIRECTS, $l, false);
}
add_action('template_redirect', function () {
	$pad = aizy_seo_pad($_SERVER['REQUEST_URI'] ?? '/');
	$l = (array) get_option(AIZY_SEO_REDIRECTS, array());
	if (!isset($l[$pad])) return;
	// Staat er (weer) gepubliceerde inhoud op het oude pad, dan wint die
	if (!is_404()) return;
	$l[$pad]['hits'] = ($l[$pad]['hits'] ?? 0) + 1; update_option(AIZY_SEO_REDIRECTS, $l, false);
	wp_safe_redirect(home_url($l[$pad]['naar']), 301, 'Aizy SEO');
	exit;
}, 1);

/* ── Categorietekst onder de producten ─────────────────────────────────────── */
function aizy_seo_cat_onder() {
	if (!function_exists('is_product_category') || !is_product_category()) return '';
	$t = get_queried_object();
	$h = $t ? get_term_meta($t->term_id, 'aizy_cat_onder', true) : '';
	return $h ? '<div class="aizy-cat-onder">' . wpautop(do_shortcode(wp_kses_post($h))) . '</div>' : '';
}
add_action('woocommerce_after_shop_loop', function () { if (!did_action('aizy_cat_onder_getoond')) { echo aizy_seo_cat_onder(); do_action('aizy_cat_onder_getoond'); } }, 20);
add_shortcode('aizy_categorie_tekst', function () { do_action('aizy_cat_onder_getoond'); return aizy_seo_cat_onder(); });
// Zonder Yoast/Rank Math: eigen titel en beschrijving voor categorieën
add_filter('pre_get_document_title', function ($t) {
	if (aizy_seo_plugin() !== 'geen' || !function_exists('is_product_category') || !is_product_category()) return $t;
	$e = get_term_meta(get_queried_object_id(), '_aizy_titel', true); return $e ?: $t;
});
add_action('wp_head', function () {
	if (aizy_seo_plugin() !== 'geen') return;
	if (function_exists('is_product_category') && is_product_category()) { $m = get_term_meta(get_queried_object_id(), '_aizy_meta', true); if ($m) echo '<meta name="description" content="' . esc_attr($m) . "\" />\n"; }
	if (is_singular() && get_post_meta(get_the_ID(), '_aizy_noindex', true) === '1') echo "<meta name=\"robots\" content=\"noindex, follow\" />\n";
}, 1);

/* ── CTA-blok [aizy_cta item="Naam" url="https://..."] of [aizy_cta] ───────── */
add_shortcode('aizy_cta', function ($a) {
	$o = wp_parse_args((array) get_option(AIZY_SEO_INSTELLINGEN, array()), array('cta_tekst' => '', 'cta_knop' => 'Meer informatie', 'cta_url' => home_url('/contact/'), 'kleur' => '#6935CC'));
	$a = shortcode_atts(array('item' => '', 'url' => ''), $a);
	$tekst = $a['item'] ? sprintf('Bekijk %s', esc_html($a['item'])) : esc_html($o['cta_tekst'] ?: get_bloginfo('description'));
	$url = esc_url($a['url'] ?: $o['cta_url']);
	$knop = esc_html($a['item'] ? 'Bekijken' : $o['cta_knop']);
	$k = esc_attr($o['kleur']);
	return "<div class=\"aizy-cta\" style=\"border:1px solid {$k}33;border-left:4px solid {$k};border-radius:8px;padding:16px 20px;margin:24px 0;display:flex;gap:16px;align-items:center;justify-content:space-between;flex-wrap:wrap\"><span style=\"font-weight:600\">{$tekst}</span><a href=\"{$url}\" style=\"background:{$k};color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none;font-weight:600\">{$knop}</a></div>";
});

/* ── Instellingen (Instellingen › Aizy SEO) ───────────────────────────────── */
add_action('admin_menu', function () {
	add_options_page('Aizy SEO-koppeling', 'Aizy SEO', 'manage_options', 'aizy-seo', function () {
		if (isset($_POST['aizy_seo_nonce']) && wp_verify_nonce($_POST['aizy_seo_nonce'], 'aizy_seo')) {
			update_option(AIZY_SEO_INSTELLINGEN, array(
				'cta_tekst' => sanitize_text_field($_POST['cta_tekst'] ?? ''), 'cta_knop' => sanitize_text_field($_POST['cta_knop'] ?? ''),
				'cta_url' => esc_url_raw($_POST['cta_url'] ?? ''), 'kleur' => sanitize_hex_color($_POST['kleur'] ?? '') ?: '#6935CC',
			));
			echo '<div class="updated"><p>Opgeslagen.</p></div>';
		}
		$o = wp_parse_args((array) get_option(AIZY_SEO_INSTELLINGEN, array()), array('cta_tekst' => '', 'cta_knop' => 'Meer informatie', 'cta_url' => '', 'kleur' => '#6935CC'));
		$r = (array) get_option(AIZY_SEO_REDIRECTS, array());
		echo '<div class="wrap"><h1>Aizy SEO-koppeling</h1><p>Versie ' . esc_html(AIZY_SEO_VERSIE) . ' · SEO-plugin: ' . esc_html(aizy_seo_plugin()) . ' · ' . count($r) . ' redirects</p>';
		echo '<p>Koppelen: maak bij Gebruikers › Profiel een <b>applicatiewachtwoord</b> aan (gebruiker met rol Redacteur, Shopmanager of Beheerder) en vul dat in het Aizy SEO-dashboard in.</p>';
		echo '<form method="post">'; wp_nonce_field('aizy_seo', 'aizy_seo_nonce');
		echo '<h2>Algemene CTA ([aizy_cta])</h2><table class="form-table">';
		echo '<tr><th>Tekst</th><td><input class="regular-text" name="cta_tekst" value="' . esc_attr($o['cta_tekst']) . '"></td></tr>';
		echo '<tr><th>Knoptekst</th><td><input class="regular-text" name="cta_knop" value="' . esc_attr($o['cta_knop']) . '"></td></tr>';
		echo '<tr><th>Link</th><td><input class="regular-text" name="cta_url" value="' . esc_attr($o['cta_url']) . '"></td></tr>';
		echo '<tr><th>Accentkleur</th><td><input name="kleur" type="color" value="' . esc_attr($o['kleur']) . '"></td></tr></table>';
		submit_button('Opslaan'); echo '</form>';
		if ($r) { echo '<h2>Redirects (301)</h2><table class="widefat striped"><thead><tr><th>Van</th><th>Naar</th><th>Gebruikt</th></tr></thead><tbody>';
			foreach ($r as $van => $x) echo '<tr><td>' . esc_html($van) . '</td><td>' . esc_html($x['naar']) . '</td><td>' . (int) ($x['hits'] ?? 0) . '</td></tr>';
			echo '</tbody></table>'; }
		echo '</div>';
	});
});
